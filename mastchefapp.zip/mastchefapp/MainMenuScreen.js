import React from 'react';
import { View, Text, StyleSheet, Image, ScrollView } from 'react-native';

export default function MainMenuScreen({ route, dishes }) {
  return (
    <View style={styles.container}>
      <Text style={styles.title}>Main Menu</Text>
      <Text style={styles.subtitle}>Total Dishes Added: {dishes.length}</Text>
      <ScrollView style={styles.scrollContainer}>
        {dishes.map((dish, index) => (
          <View key={index} style={styles.dishContainer}>
            <Image source={{ uri: dish.image }} style={styles.image} />
            <Text style={styles.dishName}>{dish.name}</Text>
            <Text style={styles.description}>{dish.description}</Text>
            <Text style={styles.price}>Price: ${dish.price}</Text>
            <Text style={styles.course}>Course: {dish.course}</Text>
            <Text style={styles.rating}>Rating: {dish.rating} Star{dish.rating > 1 ? 's' : ''}</Text>
          </View>
        ))}
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#D7C6A9', // Light brown background color
    padding: 20,
  },
  title: {
    fontSize: 24,
    marginBottom: 20,
    fontWeight: 'bold',
  },
  subtitle: {
    fontSize: 18,
    marginBottom: 10,
  },
  scrollContainer: {
    width: '100%',
  },
  dishContainer: {
    marginBottom: 20,
    padding: 10,
    backgroundColor: '#fff', // White background for dish details
    borderRadius: 5,
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.2,
    shadowRadius: 3,
    elevation: 2,
  },
  image: {
    width: '100%',
    height: 200,
    borderRadius: 10,
    marginBottom: 10,
  },
  dishName: {
    fontSize: 20,
    fontWeight: 'bold',
  },
  description: {
    fontSize: 16,
    marginVertical: 5,
  },
  price: {
    fontSize: 18,
    fontWeight: 'bold',
  },
  course: {
    fontSize: 16,
    fontStyle: 'italic',
  },
  rating: {
    fontSize: 16,
    fontWeight: 'bold',
  },
});
