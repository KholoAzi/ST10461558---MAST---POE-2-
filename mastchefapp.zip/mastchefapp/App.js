import React, { useState } from 'react';
import { NavigationContainer } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import HomeScreen from './HomeScreen';
import AddDishScreen from './AddDishScreen';
import MainMenuScreen from './MainMenuScreen';

const Stack = createNativeStackNavigator();

export default function App() {
  const [dishes, setDishes] = useState([]);

  const addDish = (newDish) => {
    setDishes((prevDishes) => [...prevDishes, newDish]);
  };

  return (
    <NavigationContainer>
      <Stack.Navigator initialRouteName="Home">
        <Stack.Screen name="Home" component={HomeScreen} options={{ title: 'Chef Menu' }} />
        <Stack.Screen name="AddDish">
          {(props) => <AddDishScreen {...props} addDish={addDish} />}
        </Stack.Screen>
        <Stack.Screen name="MainMenu">
          {(props) => <MainMenuScreen {...props} dishes={dishes} />}
        </Stack.Screen>
      </Stack.Navigator>
    </NavigationContainer>
  );
}
