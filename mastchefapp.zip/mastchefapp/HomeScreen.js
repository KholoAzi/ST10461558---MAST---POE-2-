import React from 'react';
import { View, Text, Button, StyleSheet } from 'react-native';

export default function HomeScreen({ navigation }) {
  return (
    <View style={styles.container}>
      <Text style={styles.title}>Welcome to the Chef's Menu!</Text>
      <Button title="Add a New Dish" onPress={() => navigation.navigate('AddDish')} />
      <Button title="View Main Menu" onPress={() => navigation.navigate('MainMenu')} />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#D7C6A9', // Light brown background color
  },
  title: {
    fontSize: 24,
    marginBottom: 20,
    fontWeight: 'bold',
  },
});
